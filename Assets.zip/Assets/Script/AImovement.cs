using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AImovement : MonoBehaviour
{
    public float movementspeed = 10f;
    public float rotationspeed = 50f;

    private bool isWalking = false;
    private bool isRotatingRight = false;
    private bool isRotatingLeft = false;
    private bool isWandering = false;

    Rigidbody rb;
    Animator ani;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent <Rigidbody>();
        ani = GetComponent<Animator>();
 }

public float speed = 2;
    // Update is called once per frame
    void Update()
    {
        if (isWandering == false){

            StartCoroutine(Wander());
        }
        if (isRotatingLeft == true)
        {
            transform.Rotate(transform.up * Time.deltaTime * rotationspeed);
        }
        if (isRotatingRight == true)
        {
            transform.Rotate(transform.up * Time.deltaTime * -rotationspeed);  
        }
        if (isWalking == true)
        {
            rb.AddForce(transform.forward * movementspeed);    
            ani.SetBool("IsWalking",true);
        }
       if (isWalking == false){
            ani.SetBool("IsIdle",true);
       }
 }
    
    IEnumerator Wander()
    {
        int rotationTime = Random.Range(1,3);
        int rotateWait = Random.Range(1,3);
        int rotateDirection = 1;
        int walkWait = Random.Range(1,3);
        int walkTime = Random.Range (1,3);

        isWandering = true;

        yield return new WaitForSeconds(walkWait);

        isWalking = true;

        yield return new WaitForSeconds(walkTime);

        isWalking = false;
      
        yield return new WaitForSeconds(rotateWait);

        if(rotateDirection == 1)//check if it is rotating
        {
            isRotatingLeft = true;//if it's true
            yield return new WaitForSeconds(rotationTime);//then rotate
            isRotatingLeft = false;//turn the rotation off
        }

        if(rotateDirection == 2)//same
        {
            isRotatingRight = true;
            yield return new WaitForSeconds(rotationTime);
            isRotatingRight = false;

        isWandering = false;
        
    }
    
}
}