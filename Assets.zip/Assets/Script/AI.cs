using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using System.Threading;
public class AI : MonoBehaviour
{
   
    Animator ani;
    private NavMeshAgent agent;
    public float radius;
    private void Start ()
    {
        agent = GetComponent <NavMeshAgent> ();
        ani.SetBool("IsWalking",true);

    }
    // Update is called once per frame
    private void Update()
    {
        if (!agent.hasPath)
        {
          agent.SetDestination(GetPoint.Instance.GetRandomPoint (transform, radius));
        }
    }
#if UNITY_EDITOR
    
    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(transform.position,radius);
    }
#endif    


}